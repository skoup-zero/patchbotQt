#pragma once

namespace patchbot {
}