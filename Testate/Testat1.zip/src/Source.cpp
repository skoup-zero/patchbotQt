#include <patchbot/entity.hpp>
#include <patchbot/terrain.hpp>

#include <stdexcept>
#include <iostream>
#include <vector>
#include <fstream>

/// @brief	takes a terrain and writes it into a txt file
///
/// @param	map is an instance of terrain
void write_map_to_file( const patchbot::terrain &map ) {
	unsigned int height = map.height();
	unsigned int width = map.width();

	std::ofstream output_file;
	output_file.open( "Test.txt" );

	output_file << width << std::endl << height << std::endl;
	int counter = 0;
	for( int i = 0; i < height * width; i++ ) {
		if( counter >= width ) {
			output_file << std::endl;
			counter = 0;
		}
		counter++;
		if( map.at( i )->robot() ) {
			auto temp = map.at( i )->robot();

			for( auto iter = patchbot::robot_map.begin();
				iter != patchbot::robot_map.end(); ++iter ) {

				if( iter->second == temp->type() )
					output_file << iter->first;
			}
		} else {
			for( auto iter = patchbot::tile_map.begin();
				iter != patchbot::tile_map.end(); ++iter ) {

				if( iter->second == map.at( i )->type() )
					output_file << iter->first;
			}
		}
	}
	output_file.close();
}

int main( int argc, char **argv ) {

	if( argc != 2 ) {
		std::cout << "please put a valid path for the map to load"
			<< R"(e.g.: F:\Work\Patchbot\extra\txt\koloniekarten\map.txt)" << std::endl;
		return EXIT_FAILURE;
	}
	try {
		patchbot::terrain map = patchbot::terrain::load_map_from_file( argv[1] );
		write_map_to_file( map );
	} catch( const std::exception &exc ) {
		std::cout << "Error: " << exc.what() << std::endl;
		return EXIT_FAILURE;
	}

	return EXIT_SUCCESS;
}