#include <patchbot/entity.hpp>
#include <patchbot/terrain.hpp>
#include <patchbot/exceptions.hpp>

#include <fstream>
#include <string>
#include <stdexcept>
#include <map>
#include <cctype>

using namespace patchbot;

terrain::terrain( std::vector<std::shared_ptr<tile>> &&tiles, unsigned int width,
	unsigned int height )
	:_tiles { tiles }
	, _width { width }
	, _height { height }
{}

terrain terrain::load_map_from_file( const std::filesystem::path &path ) {
	unsigned int width, height;
	unsigned int pb_start = 0, pb_goals = 0;
	std::string current_line;
	std::vector<std::shared_ptr<tile>> tiles;

	if( !std::filesystem::is_regular_file( path ) ) /* exc: irregular file */
		throw std::invalid_argument( "no valid path" );

	std::fstream init_map( path );

	try {
		std::getline( init_map, current_line );
		if( !(std::all_of( current_line.begin(), current_line.end(), isdigit )) /*exc: all strings are integers */
			|| isdigit( current_line[0] == 0 ) ) /* exc: empty char */
			throw map_format_exception { "invalid header" };

		width = stoi( current_line );
		std::getline( init_map, current_line );

		if( !(std::all_of( current_line.begin(), current_line.end(), ::isdigit )) /*exc: all strings are integers */
			|| isdigit( current_line[0] == 0 ) ) /* exc: empty char */
			throw map_format_exception { "invalid header" };

		height = stoi( current_line );
	} catch( const std::exception &exc ) {
		throw;
	}

	tiles.reserve( width * height );
	int counter = 0;

	/* reads each char of each line and creates Objects asigned to that symbol */
	while( std::getline( init_map, current_line ) ) {
		if( current_line.length() != width ) /* exc: lenght of line is correct */
			throw map_format_exception { "incorrect width" };

		for( char j : current_line ) {
			const auto r_it = robot_map.find( j );
			const auto t_it = tile_map.find( j );

			if( !(r_it == robot_map.end()) ) {/* creating robot and a tile it stands on */
				if( r_it->first == 'p' ) {
					auto temp = std::make_shared<tile>( tile_type::patchbot_start );
					temp->set_robot( std::make_shared<robot>( r_it->second ) );
					tiles.push_back( temp );
					pb_start++;
				} else {
					auto temp = std::make_shared<tile>( tile_type::enemy_start );
					temp->set_robot( std::make_shared<robot>( r_it->second ) );
					tiles.push_back( temp );
				}
			} else if( !(t_it == tile_map.end()) ) { /* creating tile */
				if( t_it->first == 'P' )
					pb_goals++;
				auto temp = std::make_shared<tile>( t_it->second );
				tiles.push_back( temp );
			} else {/* exc: invalid char */
				throw map_format_exception { "invalid symbol" };
			}
		}
		counter++;
	}
	if( counter != height ) /* exc: height of map is incorrect */
		throw map_format_exception { "incorrect height" };
	if( pb_goals < 1 ) /* exc: no server found */
		throw map_format_exception { "no goal found" };
	if( pb_start != 1 ) /* exc: less or more then one patchbot */
		throw map_format_exception { "0 or more then one patchbot start" };

	return terrain( std::move( tiles ), width, height );
}


/// GETTER
unsigned int terrain::width() const {
	return _width;
}

unsigned int terrain::height() const {
	return _height;
}
const std::shared_ptr<tile> &terrain::at( unsigned int index ) const {
	if( index > _height * _width )
		throw std::out_of_range { "index is out of range" };
	return _tiles.at( index );
}

const std::shared_ptr<tile> &terrain::at( unsigned int x, unsigned int y ) const {
	if( x >= _width || y >= _height )
		throw std::out_of_range { "coordinates out of range" };
	return _tiles.at( _width * y + x );
}