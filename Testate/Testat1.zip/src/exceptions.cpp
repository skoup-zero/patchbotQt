#include <patchbot/exceptions.hpp>

map_format_exception::map_format_exception( const char *_message )
	:_message( _message ) {}

const char *map_format_exception::what() const noexcept {
	return _message;
}