#include <patchbot/entity.hpp>
#include <map>
#include <iostream>

using namespace patchbot;

/// CLASS ROBOT
robot::robot( robot_type type )
	:_robot_type { type } {}

/// GETTER
robot_type robot::type() const {
	return _robot_type;
}


/// CLASS Tile
tile::tile( tile_type type )
	:_tile_type { type } {}

/// SETTER
void tile::set_robot( std::shared_ptr<class robot> &occupant ) {
	_occupant = occupant;
}

/// GETTER
std::shared_ptr<robot> tile::robot() const {
	return _occupant;
}

tile_type tile::type() const {
	return _tile_type;
}
