#pragma once
#include <exception>

/// @brief	throws exceptions whenever an error occurs with creating the map
class map_format_exception: public std::exception {
private:
	const char *_message;

public:
	explicit map_format_exception( const char *message_ );
	virtual const char *what() const noexcept;
};