#pragma once

namespace patchbot {
}